package_name = 'cti-toolkit'
package_version = '1.1.1'
version_string = '{} v{}'.format(package_name, package_version)
